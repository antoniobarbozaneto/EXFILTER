package com.lipogramsw.filemanager;

public class FileManager {

	
	public void copyFile(String origin, String target)
	{
		
	}
	
	public void renameFile(String origin, String target)
	{
		
	}
}
